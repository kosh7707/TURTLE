"""Render paper tables from rebuild.py output and offline TCP checks (no additional measurements)."""
import csv,json
from pathlib import Path
w=Path(__file__).resolve().parent
stats=list(csv.DictReader((w/'flight-summary.csv').open()))
v={(r['layer'],r['scenario'],r['auth'],r['name']):f"{float(r['median']):.0f}" for r in stats}
bs=chr(92)
rowend=' '+bs*2
tables=['% Requires booktabs. C = client; S = server. Times in microseconds.']
for layer,cols,headers,cap,group in [
 ('message',['CH','SH','EE','CR','SC','SCV','SF','CC','CCV','CF'],['CH','SH','EE','CR','SC','SCV','SF','CC','CCV','CF'],
  'OpenSSL client handshake-message callback entry (microseconds from first handshake-call entry). Each cell is the median of 20 new connections; -- is not present under that authentication mode.',
  ' & & C to S & '+bs+'multicolumn{6}{c}{S to C} & '+bs+'multicolumn{3}{c}{C to S}'),
 ('bio',['CH','SH','SF','CF','CAD','SAD_greeting','SAD_response'],['CH out','SH in','SF in','CF out','CAD out','Greeting in','Response in'],
  'OpenSSL client BIO record progress (microseconds from first handshake-call entry). Outgoing: entry of first write covering the labeled record. Incoming: return of the read completing the record. SF and CF designate the records ending Finished, not cryptographic work. Each cell: median over 20 connections.',None),
]:
    tables += [bs+'begin{table*}',bs+'centering',bs+'small',bs+'caption{'+cap+'}',bs+'label{tab:turtle-'+layer+'}',bs+'begin{tabular}{ll'+'r'*len(cols)+'}',bs+'toprule']
    if group: tables.append(group+rowend)
    tables += ['Scenario & Auth. & '+' & '.join(headers)+rowend,bs+'midrule']
    for s in ('S0','S1','S2','S3','S4'):
        for a in ('server','mtls'):
            tables.append(' & '.join([s,'Server' if a=='server' else 'mTLS']+[v.get((layer,s,a,col),'--') for col in cols])+rowend)
    tables += [bs+'bottomrule',bs+'end{tabular}',bs+'end{table*}','']
pairs=[('s2','S2',Path('out/tcp-evidence.57HLG5/s2net/attempts/00002')),('s4','S4',Path('out/test/artifacts/netem/run/attempts/00004'))]
tcp=[]
for key,sc,path in pairs:
    archived = w/'tcp'/key
    capture_path = archived if archived.is_dir() else path
    ck=json.loads((w/(key+'-ack-check.json')).read_text())
    report=json.loads((capture_path/'analysis.json').read_text())
    assert ck['status']=='verified' and ck['run_id']==report['run_id']
    witness,=ck['ack_witnesses']
    client=report['roles']['server']['records']['receive'];server=report['roles']['server']['records']['send']
    p=next(p for p in report['captures']['server']['client_to_server']['packets'] if p['id']==witness['packet_id'])
    cf=client[witness['contains_first_byte_of_record']-1];gr=server[witness['peer_record_fully_received_before_this_copy']-1]
    assert cf['terminates_finished'] and any(x['message']=='greeting' for x in gr['application_ranges'])
    assert p['wire_begin']<=cf['wire_begin']<cf['wire_end']<=p['wire_end'] and gr['wire_end']==p['ack_stream_offset']
    tcp.append(dict(scenario=sc,run_id=ck['run_id'],capture=str(path/'server.pcap'),packet_id=p['id'],packet_seq_raw=p['sequence'],packet_ack_raw=p['ack'],client_stream_begin=p['wire_begin'],client_stream_end=p['wire_end'],cf_record=cf['number'],cf_begin=cf['wire_begin'],cf_end=cf['wire_end'],cum_ack_to_server_offset=p['ack_stream_offset'],greeting_record=gr['number'],greeting_begin=gr['wire_begin'],greeting_end=gr['wire_end']))
with (w/'tcp-witnesses.csv').open('w',newline='') as f:
    o=csv.DictWriter(f,fieldnames=list(tcp[0]));o.writeheader();o.writerows(tcp)
tables += [bs+'begin{table*}',bs+'centering',bs+'caption{Named-copy TCP order witnesses in separate server-side, mutual-TLS captures. SEQ and ACK offsets are relative to the respective first data byte. In both cases the complete greeting ciphertext had reached client TCP before the named client packet was sent. This need not imply TLS consumption.}',bs+'label{tab:turtle-ack}',bs+'begin{tabular}{lrrrr}',bs+'toprule','Scenario & Client packet & Client SEQ range & Server greeting range & Cumulative ACK'+rowend,bs+'midrule']
for r in tcp:
    tables.append(' & '.join([r['scenario'],str(r['packet_id']),'$['+str(r['client_stream_begin'])+','+str(r['client_stream_end'])+')$','$['+str(r['greeting_begin'])+','+str(r['greeting_end'])+')$',str(r['cum_ack_to_server_offset'])])+rowend)
tables += [bs+'bottomrule',bs+'end{tabular}',bs+'end{table*}']
(w/'paper-tables.tex').write_text('\n'.join(tables)+'\n')
