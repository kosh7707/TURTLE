TURTLE: S0-S4 detailed TLS 1.3 measurements
OpenSSL 3.5.9 client (only measured endpoint), wolfSSL 5.9.4 server;
X25519, ECDSA P-256 certificates, TLS_AES_256_GCM_SHA384. IPv4 loopback,
x86-64 Linux / WSL2. Detailed raw TLS I/O with OpenSSL header and message callbacks;
no packet capture or perf in these timing samples. Application strings are each
4 bytes. Per scenario and authentication mode: 20 fresh non-resumed connections,
warmup and presend capability probes excluded. No comparisons to basic-mode latency.

Offline reproduction from this directory:
  python3 rebuild.py
  python3 format_tables.py
No TLS keys or new network connections are needed. Only the selected input
files needed to regenerate the tables are included, not the full execution
directory. The manifest preserves the original artifact hashes and settings.

message-events.csv: times at the start of a public handshake-message notification,
not generation, signature computation, verification completion, or wire transmission.
record-bio-events.csv: one row per directional record, byte offsets [begin,end),
header event, first/last BIO and socket call events with relative timestamps.
Records without a semantic label have not been assigned individual encrypted
handshake-message types. CH/SH checked against actual plaintext handshake bytes;
Finished boundary uses the attested unpadded/application-only, nonempty tail.
flight-summary.csv: ns converted to us, with sample count, Q1, median and Q3.
paper-tables.tex: three tables for LaTeX (booktabs).

The two named-copy TCP examples are from separate captured OpenSSL/OpenSSL
mutual-TLS connections, measured at the server, and are not part of the
200-connection timing distribution. S2: X25519; S4: X25519MLKEM768.
tcp/s2 and tcp/s4 contain original server PCAP, raw wire image, server events
and analysis. To independently recheck using TShark and the repository tool:
  python3 /path/to/TURTLE/tools/wireshark/check_lifecycle_capture.py tcp/s2
  python3 /path/to/TURTLE/tools/wireshark/check_lifecycle_capture.py tcp/s4
TCP offsets are relative to ISN+1 in each direction. A named packet's
cumulative ACK proves receipt by its TCP stack before that copy was sent,
not a TLS read, verification completion or application consumption.
