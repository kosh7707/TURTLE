"""Derive message callback and BIO/record progress tables; requires Python stdlib and a detailed TURTLE run."""
from collections import Counter, defaultdict
from pathlib import Path
from statistics import median, quantiles
import csv
import json
import sys

parent = Path(__file__).resolve().parent
root = Path(sys.argv[1]) if len(sys.argv)>1 else parent/'run'
def load(p): return json.loads(p.read_text())
def writecsv(name, rows):
    with (parent/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
def available(o):
    assert o['availability']=='available',o
    return o['value']
m=load(root/'manifest.json')
aggregate=load(root/'analysis.json')
assert m['status']=='complete' and not m['blocked'] and aggregate['complete']
assert aggregate['eligible_measurements']==aggregate['successful_measurements']==aggregate['measurement_count']==200
assert Counter(a['purpose'] for a in m['attempts'])=={'measurement':200,'capability':4,'warmup':10}
assert len({a['run_id'] for a in m['attempts']})==214
configs={c['id']:c for c in m['spec']['configurations']}
msg_names=('CH','SH','EE','CR','SC','SCV','SF','CC','CCV','CF')
bio_names=('CH','SH','SF','CF','CAD','SAD_greeting','SAD_response')
mt={('send',1):'CH',('receive',2):'SH',('receive',8):'EE',('receive',13):'CR',('receive',11):'SC',('receive',15):'SCV',('receive',20):'SF',('send',11):'CC',('send',15):'CCV',('send',20):'CF'}
expect_app={'S0':set(),'S1':{'CAD'},'S2':{'SAD_greeting'},'S3':{'CAD','SAD_response'},'S4':{'CAD','SAD_greeting','SAD_response'}}
messages, bounds, samples, groups=[],[],defaultdict(list),Counter()
for a in m['attempts']:
    if a['purpose']!='measurement': continue
    d=root/a['directory']
    c=configs[a['configuration']]; sn,au=c['scenario'],c['auth']
    groups[sn,au]+=1
    assert c['recording']=='detailed' and c['measured_role']=='client'
    r=load(d/'analysis.json'); o=r['observations']; cli=r['roles']['client']
    assert all(r[k] for k in ['success','ordinary_timing_sample','eligible','configuration_matches'])
    assert all(available(o[k])==True for k in ['records','headers','public_io'])
    assert c['expected']['group']=='X25519' and cli['negotiated']['group']['value'].lower()=='x25519'
    assert cli['negotiated']['cipher']['value']=='TLS_AES_256_GCM_SHA384' and cli['negotiated']['peer_verified']
    assert r['roles']['server']['negotiated']['peer_verified']==(au=='mtls')
    assert not any(r['roles'][side]['negotiated']['resumed'] for side in ('client','server'))
    ev={x['id']:x for x in map(json.loads,(d/'client/events.jsonl').read_text().splitlines())}
    sc=cli['scenario']; t0=ev[sc['begin_event']]['begin']['wall_ns']; assert t0==sc['begin']['wall_ns']
    assert all(x['connection_id']==a['run_id']==x['run_id'] for x in ev.values())
    source=dict(scenario=sn,auth=au,run_id=a['run_id'],attempt=a['directory'])
    observed=[]
    for direct in ('send','receive'):
        for n in available(o['message_notifications'][direct]):
            e=ev[n['event_id']]
            assert e['kind']=='message' and e['source']=='handshake_message' and e['direction']==direct and e['message_type']==n['message_type'] and e['call_id']==n['call_id']
            label=mt[direct,e['message_type']]; t=e['begin']['wall_ns']-t0
            messages.append(dict(**source,name=label,direction=direct,event=e['id'],tls_call=e['call_id'],tls_type=e['message_type'],message_bytes=e['requested'],callback_ns_from_start=t))
            observed.append((e['begin']['wall_ns'],label)); samples['message',sn,au,label].append(t)
    assert [v for _,v in sorted(observed)]==[k for k in msg_names if au=='mtls' or k not in ('CR','CC','CCV')]
    anchors=set()
    for direct,hello,finished in (('send','CH','CF'),('receive','SH','SF')):
        flow='client_to_server' if direct=='send' else 'server_to_client'
        recs=cli['records'][direct]; stream=(d/'client'/f'wire_{direct}.bin').read_bytes()[:sc['wire_'+direct+'_bytes']]
        marker=available(o['finished_boundary'][flow])
        assert o['finished_boundary'][flow]['basis']=='same_connection_unpadded_application_tail'
        nf=marker['record']; appbytes=o['finished_boundary'][flow]['application_bytes']
        tag=o['finished_boundary'][flow]['aead_tag_bytes']; total=0
        for i in reversed(range(len(recs))):
            rr=recs[i]; assert rr['content_type']==23 and rr['body_bytes']>1+tag
            if total==appbytes: break
            total+=rr['body_bytes']-1-tag
        assert total==appbytes and i+1==nf
        assert nf>=2 and recs[nf-1]['wire_end']==marker['wire_end']
        hellos=[rec for rec in recs if rec['content_type']==22]
        assert len(hellos)==1
        h=hellos[0]; data=stream[h['wire_begin']+5:h['wire_end']]
        assert data[0]==(1 if hello=='CH' else 2) and 4+int.from_bytes(data[1:4],'big')==len(data)
        assert data[0]!=2 or data[6:38]!=bytes.fromhex('cf21ad74e59a6111be1d8c021e65b891c2a211167abb8c5e079e09e2c8a8339c')
        for rr in recs:
            lo,hi=rr['wire_begin'],rr['wire_end']
            assert rr['content_type']==stream[lo] and rr['body_bytes']==int.from_bytes(stream[lo+3:lo+5],'big') and hi==lo+5+rr['body_bytes']
            he=ev[rr['header_event']]; assert he['kind']=='header' and bytes(he['header'])==stream[lo:lo+5]
            labels=[]
            if rr['number']==h['number']: labels.append(hello)
            if rr['number']==nf:
                assert rr['terminates_finished'] is True
                labels.append(finished)
            for ar in rr.get('application_ranges',[]):
                label={'request':'CAD','greeting':'SAD_greeting','response':'SAD_response'}[ar['message']]
                if label not in anchors and label not in labels: labels.append(label)
            links={}
            for layer,field,kind in [('bio','public_io_ranges','transport'),('socket','socket_ranges','socket')]:
                parts=sorted(rr[field],key=lambda p:(p['wire_begin'],p['wire_end']))
                assert parts[0]['wire_begin']==lo and parts[-1]['wire_end']==hi
                assert all(pa['wire_end']==pb['wire_begin'] for pa,pb in zip(parts,parts[1:]))
                first,last=ev[parts[0]['event_id']],ev[parts[-1]['event_id']]
                for e in (first,last):
                    assert e['kind']==kind and e['direction']==direct and e['success']
                    assert e['wire_begin']<hi and e['wire_end']>lo
                if layer=='bio': assert first['source']==last['source']=='openssl_bio'
                links.update({layer+'_first_event':first['id'],layer+'_first_begin_ns': first['begin']['wall_ns']-t0,
                              layer+'_last_event':last['id'],layer+'_last_end_ns':last['end']['wall_ns']-t0})
            bounds.append(dict(**source,direction=direct,record=rr['number'],wire_begin=lo,wire_end=hi,outer_type=rr['content_type'],
                               labels='/'.join(labels),header_event=he['id'],header_notify_ns=he['begin']['wall_ns']-t0,**links))
            for label in labels:
                assert label not in anchors; anchors.add(label)
                samples['bio',sn,au,label].append(links['bio_first_begin_ns' if direct=='send' else 'bio_last_end_ns'])
    assert anchors==({'CH','SH','CF','SF'}|expect_app[sn])
assert len(groups)==10 and all(n==20 for n in groups.values())
writecsv('message-events.csv',messages);writecsv('record-bio-events.csv',bounds)
stats=[]
for (kind,sn,au,label),ns in sorted(samples.items()):
    assert len(ns)==20
    qq=quantiles(ns,n=4,method='inclusive')
    stats.append(dict(layer=kind,scenario=sn,auth=au,name=label,unit='us',n=len(ns),q1=qq[0]/1e3,median=median(ns)/1e3,q3=qq[2]/1e3))
writecsv('flight-summary.csv',stats)
out=[]
for kind,labels in [('message',msg_names),('bio',bio_names)]:
    out.append(f'## {kind} (microseconds after first handshake call entry; per-cell median from 20 measurements)')
    out.append('|scenario|auth|'+'|'.join(labels)+'|')
    out.append('|'+'|'.join(['---']*2+['---:']*len(labels))+'|')
    for sn in expect_app:
        for au in ('server','mtls'):
            row=[sn,au]+[f'{median(samples[kind,sn,au,label])/1e3:.0f}' if (kind,sn,au,label) in samples else '—' for label in labels]
            out.append('|'+'|'.join(row)+'|')
    out.append('')
(parent/'flight-tables.md').write_text('\n'.join(out)+'\n')
print('\n'.join(out))
print('n:',len(groups),'x 20; message notices:',len(messages),'records:',len(bounds))
